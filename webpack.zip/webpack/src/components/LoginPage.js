// LoginPage.js
import LoginPage from './LoginPage.vue';

export default LoginPage;