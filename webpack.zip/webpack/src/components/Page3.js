// Page3.js
import Page3 from './Page3.vue';

export default Page3;