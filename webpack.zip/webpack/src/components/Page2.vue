<template>
  <div class="page2">
    <h1>页面2</h1>
  </div>
</template>

<script>
export default {
  name: 'Page2'
}
</script>

<style scoped>
@import './Page2.css';
</style>