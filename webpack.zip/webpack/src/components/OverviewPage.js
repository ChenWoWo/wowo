// OverviewPage.js
import OverviewPage from './OverviewPage.vue';

export default OverviewPage;