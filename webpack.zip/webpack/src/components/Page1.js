import Page1 from './Page1.vue'  // Ensure actual .vue file exists
export default Page1
