// Page2.js
import Page2 from './Page2.vue';

export default Page2;